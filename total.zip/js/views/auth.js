/* Auth View - Professional Silicon Design Sign In & Registration Controller */

let authMode = "signin"; // 'signin' or 'signup'

window.getRegisteredUsers = function() {
  const defaultUsers = [
    {
      id: "usr_admin_1",
      username: "Admin",
      email: "admin@vlsiverse.com",
      role: "admin",
      status: "Active",
      registeredAt: "2026-08-01 10:00 AM",
      lastActiveAt: new Date().toLocaleString(),
      solvedCount: 0,
      xp: 0
    }
  ];

  let usersList = [];
  const stored = localStorage.getItem("vlsi_registered_users");
  if (stored) {
    try {
      usersList = JSON.parse(stored);
    } catch (e) {
      usersList = [...defaultUsers];
    }
  } else {
    usersList = [...defaultUsers];
  }

  // Strip plaintext password fields if legacy items exist
  usersList.forEach(u => {
    delete u.password;
    if (!u.id) u.id = "usr_" + Math.random().toString(36).substring(2, 9);
    if (!u.role) u.role = "user";
  });

  localStorage.setItem("vlsi_registered_users", JSON.stringify(usersList));
  return usersList;
};

window.saveRegisteredUsers = function(users) {
  const sanitized = users.map(u => {
    const copy = { ...u };
    delete copy.password;
    return copy;
  });
  localStorage.setItem("vlsi_registered_users", JSON.stringify(sanitized));
};

// Loads isolated per-user progress data scoped strictly to unique userId
window.loadUserDataState = function(userObj) {
  const userId = typeof userObj === "object" ? userObj.id : (AppState.user.id || "usr_guest");
  const userKey = "vlsi_user_" + userId + "_data";
  const rawData = localStorage.getItem(userKey);
  
  if (rawData) {
    try {
      const data = JSON.parse(rawData);
      AppState.user.xp = data.xp || 0;
      AppState.user.solved_count = data.solved_count || 0;
      AppState.user.streak = data.streak || 0;
      AppState.user.completed_challenges = data.completed_challenges || [];
      AppState.user.activityLog = data.activityLog || {};
      AppState.user.progress = data.progress || {};
      AppState.user.certificates = data.certificates || [];
      AppState.user.solved_dp_ids = data.solved_dp_ids || [];
      AppState.user.bookmarked_dp_ids = data.bookmarked_dp_ids || [];

      if (window.digitalPracticeState) {
        window.digitalPracticeState.solvedIds = new Set(data.solved_dp_ids || []);
        window.digitalPracticeState.bookmarkedIds = new Set(data.bookmarked_dp_ids || []);
      }
      return data;
    } catch(e) {}
  }

  // Fresh isolated user state
  const freshData = {
    userId: userId,
    xp: 0,
    solved_count: 0,
    streak: 0,
    completed_challenges: [],
    activityLog: {},
    progress: {},
    certificates: [],
    solved_dp_ids: [],
    bookmarked_dp_ids: []
  };

  AppState.user.xp = 0;
  AppState.user.solved_count = 0;
  AppState.user.streak = 0;
  AppState.user.completed_challenges = [];
  AppState.user.activityLog = {};
  AppState.user.progress = {};
  AppState.user.certificates = [];
  AppState.user.solved_dp_ids = [];
  AppState.user.bookmarked_dp_ids = [];

  if (window.digitalPracticeState) {
    window.digitalPracticeState.solvedIds = new Set();
    window.digitalPracticeState.bookmarkedIds = new Set();
  }

  localStorage.setItem(userKey, JSON.stringify(freshData));
  return freshData;
};

// Saves current AppState user progress into their isolated localStorage bucket
window.persistCurrentUserProgress = function() {
  const userId = AppState.user.id;
  if (!userId) return;
  const userKey = "vlsi_user_" + userId + "_data";

  let dpSolved = AppState.user.solved_dp_ids || [];
  let dpBookmarked = AppState.user.bookmarked_dp_ids || [];
  if (window.digitalPracticeState) {
    dpSolved = Array.from(window.digitalPracticeState.solvedIds || []);
    dpBookmarked = Array.from(window.digitalPracticeState.bookmarkedIds || []);
  }

  const saveData = {
    userId: userId,
    xp: AppState.user.xp || 0,
    solved_count: AppState.user.solved_count || 0,
    streak: AppState.user.streak || 0,
    completed_challenges: AppState.user.completed_challenges || [],
    activityLog: AppState.user.activityLog || {},
    progress: AppState.user.progress || {},
    certificates: AppState.user.certificates || [],
    solved_dp_ids: dpSolved,
    bookmarked_dp_ids: dpBookmarked
  };

  localStorage.setItem(userKey, JSON.stringify(saveData));
};

window.renderAuth = function() {
  const container = document.getElementById("view-container");
  if (!container) return;

  container.innerHTML = `
    <div class="min-h-[85vh] flex items-center justify-center px-6 py-12 relative overflow-hidden font-sans">
      <!-- Ambient Background Glows -->
      <div class="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none"></div>
      <div class="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none"></div>

      <div class="w-full max-w-md glass-panel p-8 rounded-3xl border border-white/10 shadow-2xl relative z-10 backdrop-blur-xl">
        <!-- Logo & Header -->
        <div class="flex flex-col items-center text-center mb-6">
          <div class="w-14 h-14 rounded-2xl bg-gradient-to-tr from-blue-600 to-cyan-400 flex items-center justify-center glow-border-blue mb-3 shadow-xl shadow-blue-500/20">
            <i class="fa-solid fa-microchip text-white text-2xl"></i>
          </div>
          <h2 class="text-2xl font-heading font-extrabold text-white tracking-tight">
            VLSIVerse <span class="text-blue-500">Silicon Engine</span>
          </h2>
          <p class="text-xs text-gray-400 mt-1">Sign in to access 200+ practice problems, ASIC pipelines & virtual labs.</p>
        </div>

        <!-- Mode Selector Tabs -->
        <div class="grid grid-cols-2 p-1 bg-slate-950/60 rounded-xl border border-white/5 mb-6 text-xs font-mono">
          <button onclick="switchAuthTab('signin')" id="auth-tab-signin" class="py-2.5 rounded-lg font-bold transition-all ${authMode === 'signin' ? 'bg-blue-600 text-white shadow-md' : 'text-gray-400 hover:text-white'}">
            <i class="fa-solid fa-right-to-bracket mr-1.5"></i> Sign In
          </button>
          <button onclick="switchAuthTab('signup')" id="auth-tab-signup" class="py-2.5 rounded-lg font-bold transition-all ${authMode === 'signup' ? 'bg-blue-600 text-white shadow-md' : 'text-gray-400 hover:text-white'}">
            <i class="fa-solid fa-user-plus mr-1.5"></i> Register Account
          </button>
        </div>

        <!-- Clean Form Area -->
        <form onsubmit="handleAuthSubmit(event)" class="flex flex-col gap-4">
          ${authMode === 'signup' ? `
            <div>
              <label class="block text-[10px] text-gray-400 font-mono font-bold uppercase tracking-wider mb-1.5">Username</label>
              <div class="relative">
                <input type="text" id="auth-username" required placeholder="e.g. Nandini_RTL" class="w-full bg-[#0b0f19] border border-white/10 rounded-xl py-2.5 pl-10 pr-4 text-xs text-white focus:outline-none focus:border-blue-500 transition-colors">
                <i class="fa-solid fa-user-tag absolute left-3.5 top-3 text-gray-500 text-xs"></i>
              </div>
            </div>
          ` : ''}

          <div>
            <label class="block text-[10px] text-gray-400 font-mono font-bold uppercase tracking-wider mb-1.5">${authMode === 'signin' ? 'Email Address or Username' : 'Email Address'}</label>
            <div class="relative">
              <input type="text" id="auth-email" required placeholder="${authMode === 'signin' ? 'user@vlsiverse.com or username' : 'user@vlsiverse.com'}" class="w-full bg-[#0b0f19] border border-white/10 rounded-xl py-2.5 pl-10 pr-4 text-xs text-white focus:outline-none focus:border-blue-500 transition-colors">
              <i class="fa-solid fa-envelope absolute left-3.5 top-3 text-gray-500 text-xs"></i>
            </div>
          </div>

          <div>
            <label class="block text-[10px] text-gray-400 font-mono font-bold uppercase tracking-wider mb-1.5">Password</label>
            <div class="relative">
              <input type="password" id="auth-password" required placeholder="••••••••" class="w-full bg-[#0b0f19] border border-white/10 rounded-xl py-2.5 pl-10 pr-10 text-xs text-white focus:outline-none focus:border-blue-500 transition-colors">
              <i class="fa-solid fa-lock absolute left-3.5 top-3 text-gray-500 text-xs"></i>
              <button type="button" onclick="togglePasswordVisibility()" class="absolute right-3.5 top-3 text-gray-500 hover:text-white text-xs">
                <i class="fa-solid fa-eye" id="pass-eye-icon"></i>
              </button>
            </div>
          </div>

          <button type="submit" class="w-full py-3 mt-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-heading font-bold text-xs tracking-wider rounded-xl shadow-lg shadow-blue-500/20 transition-all hover:scale-[1.01] active:scale-95">
            ${authMode === 'signin' ? 'Sign In to Workspace' : 'Complete Registration & Sign In'}
          </button>
        </form>
      </div>
    </div>
  `;
};

window.switchAuthTab = function(mode) {
  authMode = mode;
  renderAuth();
};

window.togglePasswordVisibility = function() {
  const input = document.getElementById("auth-password");
  const icon = document.getElementById("pass-eye-icon");
  if (!input || !icon) return;
  if (input.type === "password") {
    input.type = "text";
    icon.className = "fa-solid fa-eye-slash";
  } else {
    input.type = "password";
    icon.className = "fa-solid fa-eye";
  }
};

window.handleAuthSubmit = function(e) {
  e.preventDefault();
  const emailOrUser = document.getElementById("auth-email")?.value.trim() || "";
  const password = document.getElementById("auth-password")?.value || "";
  const users = typeof window.getRegisteredUsers === "function" ? window.getRegisteredUsers() : [];

  if (!emailOrUser) {
    if (window.showToast) window.showToast("Please enter an email address or username.", "error");
    return;
  }

  const cleanEmail = emailOrUser.includes("@") ? emailOrUser.toLowerCase() : (emailOrUser.toLowerCase() + "@vlsiverse.com");
  const defaultUsername = emailOrUser.split("@")[0];
  const formattedUsername = defaultUsername.charAt(0).toUpperCase() + defaultUsername.slice(1);

  if (authMode === "signup") {
    const username = document.getElementById("auth-username")?.value.trim() || formattedUsername;

    let found = users.find(u => u.email.toLowerCase() === cleanEmail.toLowerCase() || u.username.toLowerCase() === username.toLowerCase());
    if (found) {
      if (window.showToast) window.showToast("An account with this email/username already exists! Signing you in...", "info");
      found.lastActiveAt = new Date().toLocaleString();
      window.saveRegisteredUsers(users);
    } else {
      found = {
        id: "usr-" + Date.now(),
        username: username,
        email: cleanEmail,
        password: password || "123456",
        role: "RTL Design Engineer",
        status: "Active",
        registeredAt: new Date().toLocaleString(),
        lastActiveAt: new Date().toLocaleString(),
        solvedCount: 0,
        xp: 0
      };
      users.push(found);
      window.saveRegisteredUsers(users);
    }

    AppState.user.signedIn = true;
    AppState.user.name = found.username;
    AppState.user.email = found.email;
    AppState.user.role = found.role || "RTL Design Engineer";

    window.loadUserDataState(found.email);
    window.persistCurrentUserProgress();

    localStorage.setItem("vlsi_active_user", JSON.stringify({
      name: found.username,
      email: found.email,
      role: found.role
    }));

    if (window.showToast) window.showToast(`Account ready! Welcome, ${found.username}.`, "success");
    if (window.navigateTo) window.navigateTo("dashboard");
  } else {
    // Sign In mode - Auto-register new accounts if first time signing in
    let found = users.find(u => 
      u.email.toLowerCase() === cleanEmail.toLowerCase() || 
      u.username.toLowerCase() === emailOrUser.toLowerCase() || 
      u.email.toLowerCase() === emailOrUser.toLowerCase()
    );
    
    if (!found) {
      found = {
        id: "usr-" + Date.now(),
        username: formattedUsername,
        email: cleanEmail,
        password: password || "123456",
        role: "RTL Design Engineer",
        status: "Active",
        registeredAt: new Date().toLocaleString(),
        lastActiveAt: new Date().toLocaleString(),
        solvedCount: 0,
        xp: 0
      };
      users.push(found);
      window.saveRegisteredUsers(users);
    } else {
      if (found.status === "Blocked") {
        if (window.showToast) window.showToast("Account Access Revoked: Your access has been suspended by the administrator.", "error");
        return;
      }
      found.lastActiveAt = new Date().toLocaleString();
      window.saveRegisteredUsers(users);
    }

    AppState.user.signedIn = true;
    AppState.user.name = found.username;
    AppState.user.email = found.email;
    AppState.user.role = found.role || "RTL Design Engineer";

    // Restore exact saved progress for user
    window.loadUserDataState(found.email);
    window.persistCurrentUserProgress();

    localStorage.setItem("vlsi_active_user", JSON.stringify({
      name: found.username,
      email: found.email,
      role: found.role
    }));

    if (window.showToast) window.showToast(`Welcome back, ${found.username}!`, "success");
    if (window.navigateTo) window.navigateTo("dashboard");
  }
};

window.signOutUser = function() {
  if (AppState.user.email) {
    window.persistCurrentUserProgress();
  }
  AppState.user.signedIn = false;
  localStorage.removeItem("vlsi_active_user");
  if (window.showToast) window.showToast("Signed out successfully.", "info");
  if (window.navigateTo) window.navigateTo("home");
};
